/*
 * Prolog part of Prolog-Matlab interface
 * Version 2
 * 
 * Samer Abdallah (2004)
 * Centre for Digital Music, QMUl.
 

  There are some incompatibilities between MATLAB syntax and
  Prolog syntax, that is, syntactic structures that Prolog
  cannot (easily) parse correctly
 
  .  'Command line' syntax, ie where a function of string arguments
     fn('thing','thingy') can be written as > fn thing thingy.
     Currently, you have to use quoted string arguments, eg save(`foo).
  
  .  Transpose operator (') as in x' - currentyl resolved by
     using a different postfix operator, (``), eg y=x``.
                                                               
  .  Cell referencing using braces, as in x{1,2}. Use cellref(x,1,2)
                                                               
  .  Field referencing using dot (.), eg x.thing - currently resolved         
     by using hash (#) operator, eg x#thing.           
 
  .  Using variables as arrays and indexing them. The problem is that
     Prolog doesn't let you write a term with a variable as the head
     functor. 
  
  .	a more declarative way of creating arrays and cell arrays
		and more automatic handling of types?
		- read array and choose type of prolog repn automatically
		- recursively read cell array and return {} list

		double -> float
		char -> atom? string? list of?
		struct -> list of name:value pairs?

		Perhaps we should use a local version of eval, eg
		 eval(local(_),Expr,X)
		where we use the same syntax as for matlab evaluation to construct
		a local mxArray. Obviously, many functions will be unavailable,
		but we should be able to construct multidimensional arrays and
		cell arrays in exactly the same way.
 
  The use of tagging functors to indicate return types for the ===
  Matlab evaluation operator is slightly confounded with the idea
  of tags to indicate the type of literal data in ground terms, ie
  like domain constructors. Eg, if we request foo(X)===foofun,
  is X a foo all by itself? Or does it need its own tag, so that
  X=foo(_), or even 'Foo'(_), since it is distinct from the requesting
  tag foo() in foo(X)===foofun.

**/
	  
:- module(plml, [
		ml_open/1, ml_open/2, ml_close/1, ml_open/3
	,	dropmat/2, exportmat/3 
	,	persist_term/2
	,	persist_item/2
	,	wsvar/3
	,	matbase_mat/2
	,	mlmi/2	% a little meta interpreter
	,	exec/2, eval/3, test/2
	,	(??)/1, (???)/1, (===)/2
	,	term_mlstring/3
	,	term_texatom/2
	,	optionlist/2
	,	compileoptions/2
	,	rtimes/3
	,	multiplot/2
	,  mhelp/1
	,	init/1
	,	bind_variable_names/1
	
	,	convert/2
	,	mx_type/2
	,	mx_sub2ind/3
	,	mx_put/2
	,	mx_create/2
	,	mx_string/2

	,	op(650,fy,`)	 	% quoting things
	,	op(160,xf,``)		% postfix transpose operator
	,	op(100,fy,@)		% function handles

	% note slightly reduced precedence of array operators -
	% hope this doesn't break everything...
	,	op(210,xfy,.^) 	% array exponentiation
	,	op(410,yfx,.*) 	% array times
	,	op(410,yfx,./) 	% array division
	,	op(410,xfy,.\) 	% reverse array division
	,	op(400,xfy,\) 		% reverse matrix division
	,	op(700,xfx,===) 	% variable binding/assignment in matlab query
	,	op(700,xfx,:==) 	% variable binding/assignment in matlab query
	,	op(951,fx,??) 		% evaluate term as matlab
	,	op(951,fx,???) 	% evaluate term as matlab boolean
	,	op(100,yfx,#)     % field indexing (note left-associativity)

	% FIXME: don't like these two any more
	,	op(101,yfx,/)  	% NOTE - this is higher precedence than usual
	,	op(150,yfx,|)  	% for mat locators: MatFile|VarName
/*
		op(800,xfy,&&), % short-circuit 'and'
		op(800,xfy,&),  % ordinary 'and'
 */
	% exported after being imported from ops
	,	op(1100,xfx,::)	% type specification (esp for arrays)
	]).
	
:- use_module(library(hostname)).
:- use_module(library(utils)).
:- use_module(library(ops)).
:- use_module(library(flists)).
:- use_module(library(meta)).
:-	load_foreign_library(foreign(plml)).

:- multifile(user:optionset/2).
:- multifile(user:matlabpath/2).
:- multifile(user:matlabinit/2).
:- multifile(user:directory/2).

:- op(700,xfx,===). % variable binding/assignment in matlab query
:- op(951,fx,??).  % evaluate term as matlab
:- op(951,fx,???). % evaluate term as matlab boolean
:- op(650,fy,`).	 % quoting things
:- op(160,xf,``).	 % postfix transpose operator
:- op(100,fy,@).	 % function handles
:- op(200,xfy,.^). % array exponentiation
:- op(410,yfx,.*). % array times
:- op(410,yfx,./). % array division
:- op(410,xfy,.\). % array reverse division
:- op(400,xfy,\).  % matrix reverse division
:- op(100,yfx,#).  % field indexing (note left-associativity)

:- op(101,yfx,/).  % NOTE - this is higher precedence than usual
:- op(150,yfx,|).  % for mat locators: MatFile|VarName
/*
:- op(800,xfy,&&). % short-circuit 'and'
:- op(800,xfy,&).  % ordinary 'and'
*/

:- at_halt(ml_closeall).

ml_closeall :-
	writeln('Closing all Matlab engines...\n'),
	forall(current_state(ml(Id),open), ml_close(Id)).
/*
	First, some procedures for managing connections to a database
	and to Matlab. We can connect to a local or remote matlab engine.
 */
ml_open(Id) :- ml_open(Id,localhost,[]). 
ml_open(Id,Host) :- ml_open(Id,Host,[]).
ml_open(Id,Host,Options) :- 
	options_flags(Options,Flags),
	(	(Host=localhost;hostname(Host))
	-> Exec='matlab'
	;	Exec='ssh /usr/local/bin/matlab'
	),
	format(atom(Cmd),'~w ~w',[Exec,Flags]),
	mlOPEN(Cmd,Id),
	set_state(ml(Id),open).


ml_close(Id) :- mlCLOSE(Id), set_state(ml(Id),closed).

options_flags([],'-nodesktop -nosplash -nojvm').
options_flags([jvm],'-nodesktop -nosplash').


/*
 * DCG for term to matlab conversion
 */

% these will be useful for seq (they define a sort of generalised
% lazy mapping over sequences of DCG terms)
empty([]).
empty(map(_,L)) :- empty(L).
singleton([H],H).
singleton(map(F,L),apply(F,H)) :- singleton(L,H).
properlist([H,R|T],H,[R|T]).
properlist(map(F,L),apply(F,H),map(F,T)) :- properlist(L,H,T).

null  --> "".
%cr    --> "\n".
%sp    --> " ".

% maybe(P)  --> P -> null; null.
if(A,B,_) --> {nonvar(A), call(A),!}, B.
if(_,_,C) --> C.
if(A,B)   --> if(A,B,null).

% apply functor to dcg term
apply(F,X) --> {fapply(F,X,A)}, A.
apply(F,X,Y) --> {fapply(F,(X,Y),A)}, A.

% sequence list of terms with separator
seq(L,_)     --> {empty(L)}, null.
seq(L,_)     --> {singleton(L,H)}, H.
seq(L,S)     --> {properlist(L,H,T)}, H, S, seq(T,S).
seq(L)       --> seq(L,null).         % if no separator specified, use null.


% syntax utilities
at(A)    --> {atomic(A), atom_codes(A,C)}, C.
wr(X)    --> {ground(X), sformat(S,'~w',[X])}, str(S).
str(S)   --> {ground(S), string_to_list(S,L)}, L.
brace(A) --> "{", A, "}".
paren(A) --> "(", A, ")".
sqbr(A)  --> "[", A, "]".
q(X)     --> "'",  {phrase(X,S), escape(39,39,S,QS)}, QS, "'". % 39: '
qq(X)    --> "\"", {phrase(X,S), escape(34,34,S,QS)}, QS, "\"". % 34: "
esc(B,X) --> {phrase(X,S), char_code(B,BC), escape(92,BC,S,QS)}, QS. % 92: \

% comma separated list
pl2ml_clist(I,L)    --> seq(map(lambda(X,pl2ml(I,X)),L),",").

% the big problem with Matlab syntax is that you cannot always replace
% a name representing a value with an expression that reduces to that
% value. Eg 
%    X=magic(5), X(3,4)
% is ok, but
%    (magic(5))(3,4)
% is not. Similarly x=@sin, x(0.5)  but not (@sin)(0.5)
% This is really infuriating.

pl2ml(I,q(X))       --> !, q(pl2ml(I,X)).
pl2ml(I,qq(X))      --> !, qq(pl2ml(I,X)).
pl2ml(_,atom(X))    --> !, at(X).
pl2ml(_,term(X))    --> !, wr(X). % this could be dangerous
pl2ml(_,mat(X,Y))   --> !, "dbload", paren(q((wr(X),"|",at(Y)))).
pl2ml(I,mx(X))      --> !, { mlWSALLOC(I,Z), mlWSPUT(Z,X) }, pl2ml(I,ws(Z)).
pl2ml(I,ws(A))      --> !, { mlWSNAME(A,N,I) }, at(N).
pl2ml(I,wsseq(A))   --> !, { mlWSNAME(A,N,I) }, at(N).
pl2ml(_,fn(A))      --> !, "@", at(A).
pl2ml(_,noeval(_))  --> !, {fail}. % causes evaluation to fail.

% !! This is problematic: we are using apply to represent both 
% function application and array dereferencing. For function
% calls, A must be a function name atom or a function handle
% If A is an array, it cannot be an expression, unless we 
% switch to using the paren Matlab function, which will be slower.
pl2ml(_,bind)       --> !, at(bind).
pl2ml(I,apply(A,B)) --> !, pl2ml(I,A), paren(pl2ml_clist(I,B)). 
pl2ml(I,call(A))    --> !, { A=..[H|T] }, pl2ml(I,apply(H,T)).
pl2ml(I,cellref(A,B)) --> !, at(A), brace(pl2ml_clist(I,B)). % !! what if A is an expression?
pl2ml(I,bind(A,B))  --> !, pl2ml(I,apply(bind,[A,B])). 
pl2ml(I,bind(A,B,C))  --> !, pl2ml(I,apply(bind,[A,B,C])). 
pl2ml(I,bind(A,B,C,D))  --> !, pl2ml(I,apply(bind,[A,B,C,D])). 
pl2ml(I,bind(A,B,C,D,E))  --> !, pl2ml(I,apply(bind,[A,B,C,D,E])). 
pl2ml(I,bind(A,B,C,D,E,F))  --> !, pl2ml(I,apply(bind,[A,B,C,D,E,F])). 
pl2ml(I,field(A,B)) --> !, pl2ml(I,getfield(A,q(B))).
pl2ml(I,vector(L))  --> !, sqbr(pl2ml_clist(I,L)).
pl2ml(I,cell(L))    --> !, brace(pl2ml_clist(I,L)).
pl2ml(_,feval)      --> !, at(feval).
pl2ml(I,feval(A,B)) --> !, pl2ml(I,apply(feval,[A,B])).
pl2ml(I,feval(A,B,C)) --> !, pl2ml(I,apply(feval,[A,B,C])).
pl2ml(I,feval(A,B,C,D)) --> !, pl2ml(I,apply(feval,[A,B,C,D])).
pl2ml(I,feval(A,B,C,D,E)) --> !, pl2ml(I,apply(feval,[A,B,C,D,E])).
pl2ml(I,feval(A,B,C,D,E,F)) --> !, pl2ml(I,apply(feval,[A,B,C,D,E,F])).

% pl2ml(I,`(A,B))     --> !, pl2ml(I,apply(feval,[A,B])). % !! experimental binary app. op
pl2ml(_,'$VAR'(N))  --> !, "p_", at(N).

% in the following 2 clauses, Dom is the size of the array as a double-list 
% like this: [[D1,D2,D3|...]]
% The integers don't actually have to be specified.
% eg, array(L::[_,_,_]) is a 3D array and L must be a 3 level nested list
pl2ml(I,array(L::[Dom])) --> !, { reverse(Dom,RDom) }, pl2ml(I,array_x(L,RDom)).
pl2ml(I,cell(L::[Dom])) -->  !, { reverse(Dom,RDom) }, pl2ml(I,cell_x(L,RDom)).


% alternative array syntax
pl2ml(I,arr(L)) --> !, { array_dims(L,D) }, pl2ml(I,arr_x(L,D)). 
pl2ml(I,arr_x(L,D)) --> !,
	if(is_list(L),
		( {	succ(ND,D),
				maplist(fapply(lambda(X,arr_x(X,ND))),L,Subarrays) 
			},
			pl2ml(I,apply(cat,[D|Subarrays]))),
		pl2ml(I,L)).


% these rules do the formatting recursively, but require the
% size list in reverse order.
pl2ml(I,array_x(L,RDom)) --> !,
	if(RDom=[D1|DX],
		( {	length(L,D1), length(RDom,D),
				maplist(fapply(lambda(X,array_x(X,DX))),L,Subarrays) 
			},
			pl2ml(I,apply(cat,[D|Subarrays]))),
		pl2ml(I,L)).


pl2ml(I,cell_x(L,RDom)) --> !,
	if(RDom=[D1|DX],
		( {	length(L,D1), length(RDom,D),
				maplist(fapply(lambda(X,cell_x(X,DX))),L,Subarrays) 
			},
			pl2ml(I,apply(cat,[D|Subarrays]))),
		pl2ml(I,cell([L]))).

pl2ml(_,array_x(_,_)) --> {fail}. % prevent default formatting
pl2ml(_,cell_x(_,_)) --> {fail}. % prevent default formatting


% NOTE: when constructing arrays, array/1 creates a ROW array,
% but array/2 creates a multidimensional array filling the dimensions
% in reverse order as we descend into a nested list. In particular,
%     array(2,[[1,2],[3,4],[5,6]])
% creates the matrix
%     1 3 5
%     2 4 6

% these are for actions (which have side effects)
pl2ml(I,assign(A,B))--> !, (pl2ml(I,A), "=", pl2ml(I,B)).
pl2ml(I,hide(A))    --> !, pl2ml(I,A), ";".
pl2ml(I,show(A))    --> !, pl2ml(I,A), ",".
pl2ml(I,then(A,B))  --> !, pl2ml(I,A), " ", pl2ml(I,B).

% lambda expression using new matlab syntax (hurrah)
pl2ml(I,lambda(A,B)) --> !,
	{ bind_variable_names(A) },
	"@", paren(pl2ml(I,A)), paren(pl2ml(I,B)).

% !! FIXME: for compatibility only
pl2ml(I,mat:A|B) --> pl2ml(I,mat(A,B)).
pl2ml(I,[X|XX])  --> pl2ml(I,vector([X|XX])).
pl2ml(I,{X})     --> {flist((,),X,L)}, pl2ml(I,cell(L)).

% special constants
pl2ml(_,'Infinity') --> "inf".
pl2ml(_,'Nan') --> "nan".

% operators which get mapped to matlab functions
pl2ml(I,A+B) --> pl2ml(I,plus(A,B)).
pl2ml(I,A-B) --> pl2ml(I,minus(A,B)).
pl2ml(I, -B) --> pl2ml(I,uminus(B)).
pl2ml(I, +B) --> pl2ml(I,uplus(B)).
pl2ml(I,A^B) --> pl2ml(I,mpower(A,B)).
pl2ml(I,A*B) --> pl2ml(I,mtimes(A,B)).
pl2ml(I,A/B) --> pl2ml(I,mrdivide(A,B)).
pl2ml(I,A\B) --> pl2ml(I,mldivide(A,B)).
pl2ml(I,A.^B)--> pl2ml(I,power(A,B)).
pl2ml(I,A.*B)--> pl2ml(I,times(A,B)).
pl2ml(I,A./B)--> pl2ml(I,rdivide(A,B)).
pl2ml(I,A.\B)--> pl2ml(I,ldivide(A,B)).
pl2ml(I,A:B:C)--> pl2ml(I,colon(A,B,C)).
pl2ml(I,A:B) --> pl2ml(I,colon(A,B)).
pl2ml(I,A>B) --> pl2ml(I,gt(A,B)).
pl2ml(I,A<B) --> pl2ml(I,lt(A,B)).
pl2ml(I,A>=B)--> pl2ml(I,ge(A,B)).
pl2ml(I,A=<B)--> pl2ml(I,le(A,B)).
pl2ml(I,A==B)--> pl2ml(I,eq(A,B)).
pl2ml(I,A#B) --> pl2ml(I,field(A,B)).
pl2ml(I, `B) --> pl2ml(I,q(B)).
pl2ml(I,B``) --> pl2ml(I,ctranspose(B)).
pl2ml(I,@B)  --> if(atomic(B), pl2ml(I,fn(B)), pl2ml(I,lambda('',B))).
pl2ml(I,A\\B)--> pl2ml(I,lambda(A,B)).
pl2ml(I,(A,B))--> pl2ml(I,A), ", ", pl2ml(I,B).
pl2ml(I,A=B)--> pl2ml(I,A), "=", pl2ml(I,B).

% these are the catch-all clauses which will deal with matlab names, and literals
% should we filter on the head functor?
pl2ml(_,A) --> {atomic(A)}, at(A).
pl2ml(I,F) --> {compound(F)}, pl2ml(I,call(F)).


% this is a DCG for texifying expressions (useful for matlab text)
pl2tex(A+B) --> pl2tex(A), "+", pl2tex(B). 
pl2tex(A-B) --> pl2tex(A), "-", pl2tex(B). 
pl2tex(A*B) --> pl2tex(A), "*", pl2tex(B). 
pl2tex(A.*B) --> pl2tex(A), "*", pl2tex(B). 
pl2tex(A/B) --> pl2tex(A), "/", pl2tex(B). 
pl2tex(A./B) --> pl2tex(A), "/", pl2tex(B). 
pl2tex(A\B) --> pl2tex(A), "\\", pl2tex(B). 
pl2tex(A.\B) --> pl2tex(A), "\\", pl2tex(B). 
pl2tex(A^B) --> pl2tex(A), "^", brace(pl2tex(B)). 
pl2tex(A.^B) --> pl2tex(A), "^", brace(pl2tex(B)). 

pl2tex(A\\B) --> "\\lambda", pl2tex(A), ".", pl2tex(B). 
pl2tex(@A)   --> "@", esc('_',at(A)). 
pl2tex(abs(A)) --> "|", pl2tex(A), "|". 
pl2tex(A) --> {atomic(A)}, at(A). 
pl2tex(A) --> 
	{compound(A), A=..[H|T] }, 
	pl2tex(H), paren(
		seq(map(lambda(X,pl2tex(X)),T),",")
	).



array_dims([X|_],M) :- !, array_dims(X,N), succ(N,M).
array_dims(_,0).

% colons and end

% escape character Q with character P
escape(_,_,[],[]).
escape(P,Q,[Q|X],[P,Q|Y]) :- escape(P,Q,X,Y).
escape(P,Q,[A|X],[A|Y]) :- Q\=A, escape(P,Q,X,Y).

user:portray(A|B) :- print(A), write('|'), print(B).
user:portray(Z) :- mlWSNAME(Z,N,ID), format('<~w:~w>',[ID,N]).

bind_variable_names(A) :- term_variables(A,Vars), varnames(Vars).

varnames(L) :- varnames(1,L).
varnames(_,[]).
varnames(N,[TN|Rest]) :- 
	atom_concat(p_,N,TN), succ(N,M), 
	varnames(M,Rest).


term_mlstring(I,Term,String) :- once(phrase(pl2ml(I,Term),String)).
term_texatom(Term,Atom) :- once(aphrase(pl2tex(Term),Atom)).

% evaluate or execute matlab terms
exec(Id,X)  :- 
	term_mlstring(Id,X,C), !, 
	(current_state(debug,on) -> format('exec(~w):~s\n',[Id,C]); true),
	mlEXEC(Id,C).

eval(Id,X,YS) :-
	maplist(preparelv(Id),YS,ZS), 
	exec(Id,hide(assign(vector(ZS),X))), 
	maplist(resolvelv,YS,ZS).

test(Id,X)   :- eval(Id,X,[bool(1)]).

/***
	===, ??, ??? - evaluation and execution operators.

	===/2 is like prolog's is/2 operator but using matlab compuation
	Manage all sorts of unifications and term types: literals 
	(atoms, numbers, functors), mat file locators, and mxArrays.

	???/1 evaluates a logical expression and fails if it is false.

	??/1 executes a matlab expression and dumps the Matlabs output
	to stdout.
***/

Y === X :- is_list(Y) -> eval(ml,X,Y); eval(ml,X,[Y]).
?? X    :- exec(ml,X).
??? Q   :- test(ml,Q).

/* 
 * A little meta-interpreter to do evals etc in context of a particular engine
 */

mlmi(Id,Y===X) :- !, (is_list(Y) -> eval(Id,X,Y); eval(Id,X,[Y])).
mlmi(Id,??  X)  :- !, exec(Id,X).
mlmi(Id,??? X)  :- !, test(Id,X).
mlmi(Id,G) :- mmi(Z/mlmi(Id,Z),G,F), !, F.
mlmi(Id,G) :- catch((clause(G,Body),mlmi(Id,Body)),cut,fail).



/* preparelv/3
 *
 * associates a given left value (a non-ground term to be assigend)
 * with a MATLAB workspace variable name to recieve the value.
 * These rules might not be quite right, but all unary functors
 * get mapped to newly allocated MATLAB variables --- this covers
 * all the type tags listed above: mx, float, term etc. Ground
 * terms get mapped to themselves, which means in particular that
 * atomic names like x, y, 'Z' get interpreted as MATLAB names,
 * ie MATLAB variables or functions.
*/

preparelv(I,ws(Z),ws(Z)) :- !, mlWSALLOC(I,Z). 
preparelv(I,T,ws(Z))     :- ttag(T,lv), !, mlWSALLOC(I,Z). 
preparelv(_,Z,Z)         :- atomic(Z), !. % used to be ground(Z) !!! 
preparelv(_,Z,_)         :- throw(error(bad_left_value(Z))).

resolvelv(ws(Z),ws(Z)) :- !.
resolvelv(X,ws(Z))     :- !, convert(X,ws(Z)).
resolvelv(Z,Z).

%%%%  Types database.

% type terms that are valid on the LHS of ===
ttag(ws(_),    lv).
ttag(mx(_),    lv).
ttag(float(_), lv).
ttag(int(_),   lv).
ttag(bool(_),  lv).
ttag(atom(_),  lv).
ttag(term(_),  lv).
ttag(string(_),lv).
ttag(mat(_),   lv).
ttag(tmp(_),   lv).
ttag(loc(_),   lv).
ttag(array(_), lv).
ttag(cell(_),  lv).
ttag(wsseq(_), lv).
ttag(list(_,_),lv).

% target types that require intermediate conversion to mx(_)
ttag(float(_), ws2mx).
ttag(int(_),   ws2mx).
ttag(bool(_),  ws2mx).
ttag(atom(_),  ws2mx).
ttag(term(_),  ws2mx).
ttag(string(_),ws2mx).
ttag(list(_,_),ws2mx).
ttag(loc(_),   ws2mx).

type_term(float,Y,float(Y)).
type_term(bool, Y,bool(Y)).
type_term(int,  Y,int(Y)).
type_term(atom, Y,atom(Y)).
type_term(term, Y,term(Y)).
type_term(loc,  Y,loc(Y)).



% Once the computation has been done, the MATLAB workspace contains
% the results which must be transferred in the appropriate form the
% specified left-values, in one of several forms, eg mxArray pointer,
% a float, an atom, a string or a locator. 
%
% Note that requesting a locator causes a further call
% to MATLAB to do a dbsave.
%
% If no type requestor tag is present, then a unique variable name
% is generated to store the result in the Matlab workspace. This name
% is returned in the variable as a ws blob.
% The idea is to avoid unnecessary traffic over the Matlab engine pipe.

% conversion between different representations of values
% !! FIXME: check memory management of mxArrays here

:- index(convert(1,1)).
:- hash(convert(_,_)).


% First, conversions that go direct from workspace variables
% These are all about saving directly to disk without transfering
% the value into Prolog-space.

convert(mx(Y),    ws(Z)) :- !, mlWSGET(Z,Y). 
convert(tmp(Y),   ws(Z)) :- !, mlWSNAME(Z,_,I), eval(I,dbtmp(ws(Z)),[loc(Y)]).
convert(mat(Y),   ws(Z)) :- !, mlWSNAME(Z,_,I), eval(I,dbsave(ws(Z)),[loc(Y)]).
convert(wsseq(Z), ws(Z)) :- !.

% This is the first clause that handles cells - note that this means
% the default cell format is a list of mx(_) terms
convert(cell(L::[Size->mx]), ws(Z)) :- !,
	convert(mx(X),ws(Z)), convert(cell(L::[Size->mx]), mx(X)).

convert(cell(L::[Size->Type]), ws(Z)) :-  
	type_term(Type,_,TypeTerm), ttag(TypeTerm,ws2mx), !,
	convert(mx(X),ws(Z)), convert(cell(L::[Size->Type]), mx(X)).

% return cell array as list of temporary mat file locators
convert(cell(L::[Size->tmp]), ws(Z)) :- !, 
	mlWSNAME(Z,_,I),
	eval(I,cellmap(@dbtmp,ws(Z)),[cell(L::[Size->loc])]).

% return cell array as list of permanent file locators
convert(cell(L::[Size->mat]), ws(Z)) :- !, 
	mlWSNAME(Z,_,I),
	eval(I,cellmap(@dbsave,ws(Z)),[cell(L::[Size->loc])]). 

convert(array(Y), ws(Z)) :- !, convert(mx(X),ws(Z)), convert(array(Y), mx(X)). 

% All other conversions from ws(_) go via mx(_)
convert(A, ws(Z)) :- ttag(A,ws2mx), !, convert(mx(X),ws(Z)), convert(A,mx(X)).

convert(mx(X),     mx(X)) :- !.
convert(atom(Y),   mx(X)) :- !, mlMX2ATOM(X,Y).
convert(bool(Y),   mx(X)) :- !, mlMX2LOGICAL(X,Y).
convert(float(Y),  mx(X)) :- !, mlMX2FLOAT(X,Y).
convert(int(Y),    mx(X)) :- !, mlMX2FLOAT(X,Z), Y is truncate(Z).
convert(string(Y), mx(X)) :- !, mlMX2STRING(X,Y).
convert(term(Y),   mx(X)) :- !, mlMX2ATOM(X,Z), term_to_atom(Y,Z).
convert(list(float,Y), mx(X))   :- !, mlGETREALS(X,Y). 
convert(loc(mat:Y),mx(X)) :- !, mlMX2ATOM(X,Z), term_to_atom(Y,Z).

convert(cell(L::[Size->Type]), mx(X)) :- !, 
	mx_type(mx(X),[Size->cell]),
	(Type=mx, TypeY=mx(Y); type_term(Type,Y,TypeY)),
	sfold((*),1,Size,ProdSize), !, Elems is ProdSize, % total number of elements
	mapints(
		mcall( \(I,Y) :- convert(TypeY,cref(mx(X),I)) ),
		1..Elems,FL),
	reverse(Size,RSize),
	unflatten(RSize,FL,L).

convert(array(L::[[S1|SX]]), mx(X)) :- !, convert(array(L::[[S1|SX]->float]),mx(X)).
convert(array(L::[Size->Type]), mx(X)) :- !, 
	mx_type(mx(X),[Size->double]),
	type_term(Type,Y,TypeY),
	sfold((*),1,Size,ProdSize), !, Elems is ProdSize, % total number of elements
	mapints(
		mcall( \(I,Y) :- convert(TypeY,aref(mx(X),I)) ),
		1..Elems,FL),
	reverse(Size,RSize),
	unflatten(RSize,FL,L).


% Conversions involving indexing and/or structure fields
% !! Need to worry about non gc mx atoms

convert(bool(Y),  aref(Z,I)) :- convert(mx(X),Z), mlGETLOGICAL(X,I,Y). 
convert(float(Y), aref(Z,I)) :- convert(mx(X),Z), mlGETFLOAT(X,I,Y). 
convert(int(Y),   aref(Z,I)) :- convert(mx(X),Z), mlGETFLOAT(X,I,W), Y is truncate(W). 

convert(mx(Y), cref(Z,I)) :- convert(mx(X),Z), mlGETCELL(X,I,Y). % !! non gc mx
convert(W,     cref(Z,I)) :- ttag(W,ws2mx), convert(mx(X),cref(Z,I)), convert(W,mx(X)).

convert(W, field(Z,N,I)) :- convert(mx(X),Z), mlGETFIELD(X,I,N,Y), convert(W,mx(Y)). 
convert(W, field(Z,N))   :- convert(mx(X),Z), mlGETFIELD(X,1,N,Y), convert(W,mx(Y)). 



%%% Utilities used by convert/2

wrap_locator(X,mat:X).

concat(0,_,[]) --> [].
concat(N,L,[X1|XX]) --> { succ(M,N), length(X1,L) }, X1, concat(M,L,XX).

% convert a flat list into a nest-list array representation 
% using given size specification
unflatten([N],Y,Y) :- length(Y,N).
unflatten([N|NX],Y,X) :-
	length(Y,M),
	L is M/N, integer(L), L>=1,
	phrase(concat(N,L,Z),Y),
	maplist(unflatten(NX),Z,X).


% thin wrappers
mx_type(mx(X),[Sz->Type])  :- mlMXINFO(X,Sz,Type).
mx_sub2ind(mx(X),Subs,Ind) :- mlSUB2IND(X,Subs,Ind).


% these create memory managed arrays, which are not suitable
% for putting into a cell array

% roughly, mx_create :: type -> mxarray.
mx_create([Size],mx(X))    :- mlCREATENUMERIC(Size,Z), mlNEWREFGC(Z,X).
mx_create({Size},mx(X))    :- mlCREATECELL(Size,Z), mlNEWREFGC(Z,X).
mx_string(string(Y),mx(X)) :- mlCREATESTRING(Y,Z), mlNEWREFGC(Z,X).

% MX as MUTABLE variables
mx_put(aref(mx(X),I),float(Y)) :- mlPUTFLOAT(X,I,Y).
mx_put(cref(mx(X),I),mx(Y))    :- mlPUTCELL(X,I,Y). % !! ensure that Y is non gc
mx_put(mx(X),list(float,Y))    :- mlPUTFLOATS(X,1,Y). 

wsvar(ws(A),Name,Engine) :- mlWSNAME(A,Name,Engine).
/*
 * Dealing with the Matbase
 *
 * The Matbase is a file system tree which contains lots of
 * MAT files which have been created by using the dbsave
 * Matlab function.
 */

% Deleting MAT files
dropmat(Eng,mat:A|B)       :- exec(Eng,dbdrop(q(term(A|B)))).
exportmat(Eng,mat:A|B,Dir) :- exec(Eng,copyfile(dbpath(q(term(A|B))),q(term(Dir)))).

% ok, this needs to traverse the term's functor tree
% converting each matlab ws blob into either at matbase
% locator or a literal value if it is a string or a scalar.
%
% persist_term(X,Y) should be true if Y is a persistent form of X

persist_item(mat:T,mat:T) :- !.  

persist_item(ws(A),B) :- !,
	mlWSNAME(A,_,Eng), 
	eval(Eng,typecode(ws(A)),[int(Numel),bool(IsNum),bool(IsChar)]),
	(	Numel=1, IsNum=1
	->	convert(float(B),ws(A)) 
	;	IsChar=1
	-> convert(atom(AA),ws(A)), B= `AA
	;	convert(mat(B),ws(A))
	).


% !! TODO - 
%     deal with collections - we can either save the aggregate
%     OR save the elements individually and get a prolog list of the
%     locators.
persist_item(wsseq(A),cell(B)) :- 
	mlWSNAME(A,_,Eng), 
	test(Eng,iscell(ws(A))), 
	eval(Eng,wsseq(A),[cell(B::[_->mat])]).

persist_item(mx(X),B) :- 
	mx_type(mx(X),[Size->Type]),
	(	Size=[1], Type=double
	->	convert(float(B),mx(X)) 
	;	Type=char
	-> convert(atom(AA),mx(X)), B= `AA
	;	current_state(ml(Id),open),  % first available engine to save
		eval(Id,dbsave(mx(X)),[term(BB)]), B=mat:BB
	).

persist_item(A,A)   :- atomic(A).

persist_term(TA,TB) :- 
	(	persist_item(TA,TB), !
	;	mapargs(persist_term,TA,TB)).



/*
 * From here on, we have straight Matlab utilities
 * rather than basic infrastructure.
 */


% for dealing with paths and current directory
% Initialise environment for a particular experiment - this reads
% the predicates directory and matlabpath to get the working directory
% and matlab path, then changes both Prolog and Matlab to the working
% directory, and adds all the bits to the matlab path.

init(X) :-
	(directory(X,WD) 
	-> format('Changing directory to ~w\n',WD),
		exec(ml,cd(`WD))
	;	true
	),                                                      
	forall( 
		(matlabpath(X,MPath), member(D,MPath)),
		addpath(D)),
	forall( matlabinit(X,Cmd), ?? Cmd).                         
					                                                                   
addpath(local(D)) :- !, exec(ml,padl(q(D))).
addpath(D) :- !, exec(ml,padd(q(D))).


% for dealing with option lists

mhelp(X) :- exec(ml,help(q(X))).

optionlist([],[]).
optionlist([Option:Value|X],[`Option,Value|Y]) :- optionlist(X,Y).

% compileoptions :: list (optionset | atom:value | struct) -> struct.
compileoptions(Opts,Prefs) :-
	rec_optslist(Opts,OptsList),
	addargs(prefs,OptsList,Prefs).

rec_optslist([],[]).
rec_optslist([H|T],L) :-
	( % mutually exclusive types for H
		optionset(H,Opts1) -> optionlist(Opts1,Opts)
	;  H=Name:Value       -> Opts=[`Name,Value]
	;	is_list(H)         -> rec_optslist(H,Opts) 
	; /* assume struct */    Opts=[H]
	),
	rec_optslist(T,TT),
	append(Opts,TT,L).

rtimes(X,Y,Z) :-
	( var(X) -> X is Z/Y
	; var(Y) -> Y is Z/X
	;           Z is X*Y).

					
% Execute several plots as subplots. The layout can be
% vertical, horizontal, or explicity given as Rows*Columns.


% mplot is a private procedure used by multiplot
mplot(subplot(H,W),N,Plot,Ax) :- ?? then(hide(subplot(H,W,N)), Plot), Ax===gca.
mplot(figure,N,Plot,Ax) :- ?? then(hide(figure(N)), Plot), Ax===gca.

multiplot(Type,Plots) :- multiplot(Type,Plots,_).

multiplot([Layout|Opts],Plots,Axes) :- !,
	multiplot(Layout,Plots,Axes),
	member(link(A),Opts) ->
		?? then(hide(linkaxes(Axes,`off)), hide(linkaxes(Axes,`A)))
	;	true.

multiplot(figs(P..Q),Plots,Axes) :- !,
	length(Plots,N),
	natural(P), Q is P+N-1,
	findall(K,between(P,Q,K),PlotNums),
	maplist(mplot(figure),PlotNums,Plots,Axes).
	
multiplot(Layout,Plots,Axes) :-
	length(Plots,N),
	member(Layout:H*W,[vertical:N*1, horizontal:1*N, H*W:H*W]),
	rtimes(H,W,N), % bind any remaining variables
	findall(K,between(1,N,K),PlotNums),
	maplist(mplot(subplot(H,W)),PlotNums,Plots,Axes).




% Listing mat files actually in matbase
matbase_mat(Matbase,mat:D/F|x) :-
	atom_concat(Matbase,'/d*',DirPattern),
	expand_file_name(DirPattern,Dirs),
	member(FullDir,Dirs), 
	file_base_name(FullDir,D),
	atom_concat(FullDir,'/m*.mat',FilePattern),
	expand_file_name(FilePattern,Files),
	member(File,Files),
	file_base_name(File,FN),
	atom_concat(F,'.mat',FN).
	
