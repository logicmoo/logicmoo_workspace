% Functor lists
% ie, lists built up using a pairing functor other than .
% Note, these functor lists do NOT have a nil element - the
% last item in the list is the 2nd argument to the final
% functor term, which can therefore be a term headed by any
% other functor. Eg:
% (1,(2,3))    <-> [1,2,3]
% (1,(2,(3+4)) <-> [1,2,(3+4)]

:- module(flists,[
	flist/3,
	flist_vt/3,
	flength/3,
	flength_vt/3,
	fmember/3,
	flip/3,			% call predicate with 2 args swapped
	fapply/3,   fapply/4,
	fmap/4
]).

:- module_transparent fapply/3, fmap/4, flip/3.

% flist :: ?functor, ?functorList, ?list.
flist(F,FL,[A|BL]) :- FL =.. [F,A,B], functor(B,F,2), flist(F,B,BL). 
flist(F,FL,[A,B]) :- FL =.. [F,A,B], not(functor(B,F,2)). 
flist(F,A,[A]) :- not(functor(A,F,2)). 

% flist_vt :: ?functor, ?functorList, ?list.
flist_vt(_,FL,[FL]) :- var(FL), !.
flist_vt(F,FL,[A|BL]) :- FL =.. [F,A,B], flist_vt(F,B,BL). 
flist_vt(F,A,[A]) :- not(functor(A,F,2)). 

% flength :: ?functor, ?functorList, ?nonnegative.
flength(F,FL,N) :- FL=..[F,_,B], flength(F,B,M), succ(M,N).
flength(F,FL,1) :- not(functor(FL,F,2)).

% This version handles lists where the last element is variable (counts as 1)
% flength_vt :: ?functor, ?functorList, ?nonnegative.
flength_vt(_,FL,1) :- var(FL), !.
flength_vt(F,FL,N) :- FL=..[F,_,B], flength_vt(F,B,M), succ(M,N).
flength_vt(F,FL,1) :- not(functor(FL,F,2)).

% fmember :: ?functor, ?thing, ?functorList.
fmember(F,X,XS) :- XS =.. [F,X,_].	
fmember(F,X,XS) :- XS =.. [F,_,T], fmember(F,X,T).	
fmember(F,X,X) :- not(functor(X,F,2)).

% call P with 2 args reversed
flip(P,X,Y) :- call(P,Y,X).

% wrap X with functor F, return Y=F(X).
fapply(F,X,Y) :- atom(F), !, 
	( var(Y), flist((,),X,XX), Y=..[F|XX]
	; nonvar(Y), Y=..[F|XX], flist((,),X,XX)).

% apply lambda term to another term
fapply(lambda(X,F),Y,G) :- !, copy_term(X:F,Y:G).

fapply(T,X,Y) :- 
	T=..L,
	flist((,),X,XX),
	append(L,XX,LL),
	Y=..LL.

fapply(F,X,Y,Z) :- fapply(F,(X,Y),Z).


					
% generalised mapping predicate
fmap(Functors,Pred,X,Y) :- nonvar(X),
	X=..[F|A], 
	member(F,Functors),
	maplist(flists:fmap(Functors,Pred),A,B),
	Y=..[F|B].

fmap(Functors,Pred,X,Y) :- nonvar(Y),
	Y=..[F|B],
	member(F,Functors),
	maplist(flists:fmap(Functors,Pred),A,B),
	X=..[F|A].

fmap(Functors,Pred,X,Y) :- 
	(nonvar(X), X=..[F|_]; nonvar(Y), Y=..[F|_]),
	\+member(F,Functors),
	call(Pred,X,Y).
	
