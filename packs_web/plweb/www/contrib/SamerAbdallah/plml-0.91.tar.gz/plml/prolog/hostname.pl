% when loaded, this sets the hostname/1 predicate.
:- module(hostname,[]).

init :-
	open(pipe('hostname -s'),read,SID), 
	call_cleanup(
		(read_line_to_codes(SID,C), atom_codes(H,C), assert(user:hostname(H))),
		_, close(SID)).

:- current_predicate(hostname,_) 
	-> hostname(H), format('% hostname was already set to ~w\n',[H])
	;  init, hostname(H), format('% hostname set to ~w\n',[H]).
