% Some general utilities

:- module(utils,[
		extensible/1	% declare dynamic multifile predicate
	,	natural/1		% test or enumerate natural numbers
	,	isfinite/1     % check number is non NaN or Inf
	,	int/1				% test or enumerate integers
	,	exhaust/1		% trigger all solutions to a goal (SIDE EFFECTS)
	,	iterate/3		% apply predicate recursively till failure
	,	filter/3			% filter elements of list that satisfy a predicate
	,	sfold/4			% structural fold for lists
	,	addargs/3		% add extra args to head functor of term
	,	print_list/1	% writes each element on a new line (SIDE EFFECTS)
	,	printq_list/1	% as print_list but quotes atom as necessary
	,	tofile/2			% send output to a named file (SIDE EFFECTS)
	,	dir/2				% directory listing
	,	path_atom/2		% expand paths
	,	expand_path/2	% expand paths
	,	open_with/2		% apply shell command to a file (SIDE EFFECTS)
	,	open_with/3		% apply shell command to a file with options (SIDE EFFECTS)
	,	shellcmd/2		% apply shell command to arguments
	,	open_/1			% open with 'open' command (Mac OS X).
	, 	fmt_shellcmd/3 % format a shell command with switches and args
	,	aformat/3		% like sformat but makes an atom
	,	read_char_echo/1 % read one character and echo it immediately
	,	set_state/2, switch/2 % these do the same thing
	,	current_state/2
	,  parallel/1 		% parallel computation using threads
	,	browse/2			% browse predicate with unknown arity
%	,	say/1
	,	aphrase/2		% like phrase but makes an atom instead of a string
	,	aphrase/3		% like aphrase but takes code list
	,	get_key/2		% read and validate keypress
	,	userchk/1		% unary predicate which allows user to force failure
	,	for_naturals/2 % call predicate with natural numbers 1 to N
	,	mapints/2      % call predicate with integers
	,	mapints/3      
	,  rep/3          % make a list of repeats of the same term
	,	copy_head/2    % check terms for same head and arity
	,	reinstatevars/3
	,	reinstatevars/4
	,	measure/3      % match list lengths
	,	dropWhile/3
	,	takeWhile/3
	,	unify_args/5
	,	mapargs_xx/6
	,	list_idx1_member/3  % like nth1 but more useful argument order

	% map predicate over args of a term, keeping head
	,	mapargs/2, mapargs/3, mapargs/4
	,	mcall/2, mcall/3, mcall/4
	,	in/2

	,	bt_call/2		% Construct backtrackable operation

	% different kinds of database update
	,	bt_assert/1
	,	bt_retract/1
	,	strict_assert/1
	,	strict_retract/1

	% more functional programming stuff
	%	,	rfoldl/4			% relational fold left
	,	getopt/4
	]).

:- use_module(library(ops)).

:- module_transparent 
	extensible/1,
	exhaust/1,
	iterate/3,
	filter/3,
	tofile/2,
	aphrase/2,
	aphrase/3,
	dropWhile/3,
	takeWhile/3,
	for_naturals/2,
	mapints/2, mapints/3,
	mcall/2, mcall/3, mcall/4,
	mapargs/2, mapargs/3, mapargs/4,
	mapargs_x/5, mapargs_x/6, mapargs_xx/6.

:- module_transparent bt_call/2, bt_assert/1, bt_retract/1.
:- module_transparent strict_assert/1, strict_retract/1.

% declares 'extensible' predicates, ie ones that can have new clauses
% added in other files.
extensible(P) :- dynamic(P), multifile(P).

%:- extensible(user:false/1).
:- multifile user:path/2.
:- multifile user:demo/1.
:- multifile user:speak/3.
:- dynamic current_state/2.


% should naturals start at zero or 1?
natural(N) :- (var(N);integer(N)), between(0,inf,N).
int(N)     :- nonvar(N), integer(N).
int(N)     :- var(N), (N=0; (between(1,inf,M), (N=M; N is -M))).
isfinite(N):- catch(_ is N+0,error(_,_),fail). % !! workable hack

% simple testing and enumration of values in some sets
X in A--\B   :- X in A--(\B).
X in \A--(\B):- !, ch(A<X), ch(X<B).
X in \A--B   :- !, ch(A<X), ch(X=<B).
X in A--(\B) :- !, ch(A=<X), ch(X<B).
X in A--B    :- !, ch(A=<X), ch(X=<B).
X in A..B    :- integer(A), integer(B), between(A,B,X). 
X in {CList} :- member_clist(X,CList).
X in natural :- natural(X). % enumerate!
X in integer :- int(X). % enumerates!
X in real    :- number(X). % same as X :: real


ch(_  =<inf) :- !.
ch(inf=< _ ) :- !, fail.
ch(-inf=< _) :- !.
ch(_ =<(-inf)) :- !, fail.
ch(A=<B) :- !, A=<B.

ch(inf<_  ) :- !, fail.
ch(_  <inf) :- !.
ch(_   <(-inf)) :- !, fail.
ch(-inf<_     ) :- !.
ch(A<B) :- !, A<B.
% repeat until failure, then succeed.
exhaust(Q) :- call(Q), fail; true.

% apply recursively until failure, then return final value.
iterate(P,X,Y) :- call(P,X,Z) -> iterate(P,Z,Y); Y=X.               

% sfold operator into list - this is a *structural* fold applied to a term,
% rather than a relational fold using a predicate name.
sfold(_,E,[],E).
sfold(O,E,[X|XX],R) :- R=..[O,X,YY], sfold(O,E,XX,YY).




% Divert any writing to given file while evaluating Z
tofile(File,Z) :- 
	tell(File), !,
	(call(Z), fail; told). 

% Directory listing
dir(Pattern,File) :-
	expand_file_name(Pattern,List),
	member(File,List).

path_atom(P,C) :- path(P,C), atom(C).
	
path_atom(PA/B,C) :-
	once((nonvar(C); nonvar(B); nonvar(PA))),
	path_atom(PA,A),
	concat3atoms(A,'/',B,C).


path_atom(Path,Atom) :- path(Path, Def), \+atom(Def), path_atom(Def,Atom).
path_atom(Path,Atom) :-
	nonvar(Path),
	\+path(Path,_),
	Path\=_/_,
	Atom=Path.

concat3atoms(A,B,C,ABC) :-
	nonvar(A), nonvar(B), nonvar(C), !, concat_atom([A,B,C],ABC).

concat3atoms(_,_,_,ABC) :- var(ABC), !, fail.
concat3atoms(A,B,C,ABC) :- nonvar(C), !, atom_concat(AB,C,ABC), atom_concat(A,B,AB). 
concat3atoms(A,B,C,ABC) :- nonvar(A), !, atom_concat(A,BC,ABC), atom_concat(B,C,BC). 
concat3atoms(A,B,C,ABC) :-
	maplist(atom_codes,[B,ABC],[BX,ABCX]),
	append(ABX,CX,ABCX),
	append(AX,BX,ABX),
	maplist(atom_codes,[A,C],[AX,CX]).

% get system to expand things like ~, *, ? (Must return unique path)
expand_path(P,FP) :- path_atom(P,PP), expand_file_name(PP,[FP]).

open_with(Q,P) :- open_with(Q,P,[]).
open_with(Q,P,Opts) :- 
	expand_path(P,FP), 
	(member(bg,Opts) -> OO=' &'; OO=''),
	sformat(S,'~w ~q~w',[Q,FP,OO]), 
	shell(S).

open_(P) :- open_with(open,P).

% Execute a shell command on a given list of arguments
shellcmd(Head,Args) :-
	concat_atom([Head|Args],' ',Cmd),
	shell(Cmd,_Status).

% make a shell command string
fmt_shellcmd(Prog,Args,Cmd) :-
	phrase(utils:shellcmd(l_(Args)),FArgs),
	concat_atom([Prog|FArgs],' ',Cmd).

shellcmd(l_([]))    --> !, [].
shellcmd(l_([H|T])) --> !, shellcmd(H), shellcmd(l_(T)).
shellcmd(s(N,V))  --> !, shellcmd(s(N)), shellcmd(V).
shellcmd(q(X)) --> !, { concat_atom(['"',X,'"'],A) }, [A].
shellcmd(s(N)) --> !, { 
	(atom_codes(N,[_]) -> F='-' ; F='--'),
	atom_concat(F,N,A) }, [A].
shellcmd(l(X)) --> [X].


% like sformat but produces an atom
aformat(A,Fmt,Args) :- format(atom(A),Fmt,Args).

% Add an extra argument to a term, eg spam(fish,cake) -> spam(fish,cake,Arg)
addarg(Term,Arg,NewTerm) :- addargs(Term,[Arg],NewTerm).
addargs(Term,Args,NewTerm) :-
	var(NewTerm) ->
		(Term=..L,
		append(L,Args,LL),
		NewTerm=..LL)
	;
		(NewTerm=..LL,
		append(L,Args,LL),
		Term=..L).


print_list([]) :- writeln('~'), nl.
print_list([H|T]) :- writeln(H), print_list(T).

printq_list([]) :- writeln('~'), nl.
printq_list([H|T]) :- writeq(H), nl, printq_list(T).

read_char_echo(C) :-
	get_single_char(Code), 
	put_code(Code), flush_output,
	char_code(C,Code). 

% Manage function, mutable state predicate
switch(Flag,Value) :- set_state(Flag,Value).
set_state(Flag,Value) :-
	ground(Flag),
	retractall(current_state(Flag,_)),
	assert(current_state(Flag,Value)).


% Use this by giving a list of queries of the form
%    [Vars2:Goal, Vars2:Goal2, ...]
% where Vars is the term that each thread must return
% when it has finished computing its Goal. The 
% parallel predicate finishes when all the threads
% have finished, and should result in all the Vars
% being bound appropriately. 

parallel(Queries) :-
	maplist(async,Queries,Collecters),
	maplist(call,Collecters).

% these are used to initiate and wait for each
% computation thread.
async_collect(Id,X:_) :- thread_join(Id,exited(X)).
async(X:Goal,utils:async_collect(Id,X:_)) :-
	thread_create((Goal,thread_exit(X)),Id,[]).

browse(P/A,Goal) :-
	current_predicate(P/A),
	length(L,A),
	Goal=..[P|L],
	call(Goal).



/*
user:speak(int(N)) --> { number_codes(N,C) }, C.
user:speak(wr(T))  --> { sformat(S,'~w',[T]) }, speak(str(S)).
user:speak(str(S)) --> { string_to_list(S,L) }, L.

say(Thing) :- 
	phrase(user:speak(Thing),Phrase), !,
	hostname(Hostname), format('~w> ~s\n',[Hostname,Phrase]),
	(current_state(speech,on) -> open_with(say,Phrase); true).
*/

aphrase(X,A) :- aphrase(X,A,_). 
aphrase(X,A,S) :- 
	(	ground(A) 
	->	atom_codes(A,S), phrase(X,S)
	;	phrase(X,S), atom_codes(A,S)).


get_key(Valid,C) :-
	read_char_echo(D), nl,
	(	member(D,Valid) -> C=D
	;	D='\n' -> get_key(Valid,C) % this improves interaction with acme
	;	write('Unknown command:'), writeq(D), nl,
		write('Command? '),
		get_key(Valid,C)).


% apply predicate to each natural number from 1 to N
for_naturals(0,_).
for_naturals(N,P) :- succ(M,N), call(P,N), for_naturals(M,P). 

% mapping predicates over lists of integers
mapints(_,M..N) :- N<M, !.
mapints(P,M..N) :- call(P,M), plus(M,1,L), mapints(P,L..N).

mapints(_,M..N,[])    :- N<M, !.
mapints(P,M..N,[X|T]) :- call(P,M,X), plus(M,1,L), mapints(P,L..N,T).

% Make a list consisting of N repeats of the same term
rep(0,_,[]).
rep(N,A,[A|X]) :- 
	(	nonvar(N) 
	-> succ(M,N), rep(M,A,X)
	; rep(M,A,X), succ(M,N)
	).

% map binary predicate to args of a term preserving head

mapargs(P,T1) :- 
	functor(T1,_,N), 
	mapargs_x(1,N,P,T1).

mapargs(P,T1,T2) :-
	(	nonvar(T1)  
	-> functor(T1,F,N), functor(T2,F,N)
	;	functor(T2,F,N), functor(T1,F,N)),
	mapargs_x(1,N,P,T1,T2).

mapargs(P,T1,T2,T3) :-
	functor(T1,F,N),
	functor(T2,F,N),
	functor(T3,F,N),
	mapargs_x(1,N,P,T1,T2,T3).

mapargs_x(I,N,P,T1) :-
	(	I>N -> true
	;  arg(I,T1,X1),
		call(P,X1),
		succ(I,J), mapargs_x(J,N,P,T1)).

mapargs_x(I,N,P,T1,T2) :-
	(	I>N -> true
	;  arg(I,T1,X1),
		arg(I,T2,X2),
		call(P,X1,X2),
		succ(I,J), mapargs_x(J,N,P,T1,T2)).

mapargs_x(I,N,P,T1,T2,T3) :-
	(	I>N -> true
	;  arg(I,T1,X1),
		arg(I,T2,X2),
		arg(I,T3,X3),
		call(P,X1,X2,X3),
		succ(I,J), mapargs_x(J,N,P,T1,T2,T3)).



% true if T1 and T2 have the same head and arity
copy_head(T1,T2) :- functor(T1,N,A), functor(T2,N,A).

% reverse of numbervars. Each '$VAR'(N) subterm of X is replaced
% with the Nth element of V, which can be uninstantiated on entry
reinstatevars(V,'$VAR'(N),Y) :- !, nth0(N,V,Y).
reinstatevars(_,X,Y) :- atomic(X), !, Y=X.
reinstatevars(V,X,Y) :- mapargs(reinstatevars(V),X,Y).

% version of reinstate vars that uses an arbitrary functor instead of $VAR
reinstatevars(F,V,T,Y) :- functor(T,F,1), !, arg(1,T,N), nth0(N,V,Y).
reinstatevars(_,_,X,Y) :- atomic(X), !, Y=X.
reinstatevars(F,V,X,Y) :- mapargs(reinstatevars(F,V),X,Y).

% true if Out is the same length as Ruler but matches In as far as possible
% measure(Ruler,In,Out).
measure([],_I,[]).
measure([_|R],[],[_|O]) :- measure(R,[],O).
measure([_|R],[X|I],[X|O]) :- measure(R,I,O).

dropWhile(P,[X|T],V) :- call(P,X) -> dropWhile(P,T,V); V=[X|T].
takeWhile(P,[X|T],O) :- call(P,X) -> O=[X|V], takeWhile(P,T,V); O=[].

% this unifies N consecutive arguments of Src and Dest starting
% from SI and DI in each term respectively
unify_args(_,_,_,_,0).
unify_args(Src,SI,Dest,DI,N) :-
	arg(SI,Src,X), arg(DI,Dest,X), !,
	succ(SI,SI2), succ(DI,DI2), succ(N2,N),
	unify_args(Src,SI2,Dest,DI2,N2).

mapargs_xx(_,_,_,_,_,0).
mapargs_xx(Pred,Src,SI,Dest,DI,N) :-
	arg(SI,Src,SX), arg(DI,Dest,DX), call(Pred,SX,DX), !,
	succ(SI,SI2), succ(DI,DI2), succ(N2,N),
	mapargs_xx(Pred,Src,SI2,Dest,DI2,N2).

userchk(T) :- format('~w [y,n]? ',[T]), get_key([y,n],y).


mcall(P,A) :- mc(P,\(A),Q), Q.
mcall(P,A,B) :- mc(P,\(A,B),Q), Q.
mcall(P,A,B,C) :- mc(P,\(A,B,C),Q), Q.
mcall(P,A,B,C,D) :- mc(P,\(A,B,C,D),Q), Q.

mc(Tuple:-Body,T,B) :- !, copy_term(Tuple:-Body,T:-B).
%mc(Z\\P,\(A),PA)    :- !, copy_term(Z\\P,A\\PA).
mc(P,T,true)        :- P=..[\|_], !, copy_term(P,T).
mc(P,T,PA)          :- T=..[\|A], addargs(P,A,PA).

%member_clist(_,Z) :- var(Z), !, fail.
member_clist(A,A) :- A\=(_,_).
member_clist(A,(A,_)).
member_clist(A,(_,B)) :- member_clist(A,B).



% Backtrackable database updates

bt_call(Do,Undo) :- Do, (true; once(Undo), fail).
bt_assert(H) :- bt_call(assert(H),retract(H)).
bt_retract(H) :- bt_call(retract(H), assert(H)).

strict_assert(H) :- \+call(H), bt_call(assert(H),retract(H)).
strict_retract(H) :- call(H), bt_call(retract(H), assert(H)).

list_idx1_member(L,I,X) :- nth1(I,L,X).

%rfoldl(_Pred,E,[],E).
%rfoldl(Pred,E,[X|XS],Z) :-
%	mcall(Pred,E,X,Y),
%	rfoldl(Pred,Y,XS,Z).

% mode getopt(in,out,out,any)  is nondet.
% mode getopt(in,in,out,in)  is det.
getopt(Opts,Name,Val,Default) :- member(Name:Val,Opts) *-> true; Val=Default.


/* Might include these at some point

% wrap X with functor F, return Y=F(X).
%app(F,X,Y) :- atom(F), !, 
%	( var(Y), flist((,),X,XX), Y=..[F|XX]
%	; nonvar(Y), Y=..[F|XX], flist((,),X,XX)).

% apply lambda term to another term
app(X\\F,Y,G) :- !, copy_term(X\\F,Y\\G).
app(T,A,Z)   :- addargs(T,[A],Z). 
app(T,A,B,Z) :- addargs(T,[A,B],Z).
app(T,A,B,C,Z) :- addargs(T,[A,B,C],Z).

applist(F,N,A,Z) :- length(Z,N), maplist(app(F),A,Z).
applist(F,N,A,B,Z) :- length(Z,N), maplist(app(F),A,B,Z).
applist(F,N,A,B,C,Z) :- length(Z,N), maplist(app(F),A,B,C,Z).

*/


filter(_,[],[]).
filter(P,[H|T],FL) :- call(P,H) -> FL=[H|FT], filter(P,T,FT); filter(P,T,FL).
