/* 
 * ops.pl - Operator declarations
 *
 * It seems that operator declarations float to the top - these are all
 * declared here to avoid possible precedence confusion that results when
 * conflicting operator declarations are scattered across modules.
 */

:- module(ops,[
		op(550,xfx,..)		% range of integers
	,	op(550,xfx,--)		% closed real interval
	,	op(600,xfx,--\)	% half open real interval
	,	op(1100,xfx,:<:)	% subtype declaration
	,	op(1100,xfx,::=)	% definition
	,	op(1100,xfx,:=:)	% type equivalence/definition
	,	op(1100,xfx,::)	% declaration
	,	op(1100,xfx,<-)	% element of, instance etc.
	%,	op(1050,yfx,�)		% restriction, eg real�integer means fractional
	,	op(750,xfy,\\)		% lambda abdstraction
	,	op(400,xfy,\) 		% reverse matrix division
	,	op(800,xfx,~)		% for annotations
	%	,	op(900,fy,seq)  % deprecated for now
	,	op(900,fy,maybe)
	,	op(900,fy,struct)
	,	op(900,fy,options)
	%,	op(900,fy,model)
	,	op(100,yfx,@)		% used for signal@rate...
	,	op(200,yfx,++)		% used for sequential composition
	,	op(700,xfx,in)
	,	op(150,yfx,`)     % function application
	,	op(100,yfx,/)	
	%,	op(400,xfy,>>)	% monad sequencing NB: standard prolog has yfx not xfy
	%,	op(400,xfy,>>=)	% monad bind
	,	op(1050,xfy,>>)	% monad sequencing NB: standard prolog has yfx not xfy
	,	op(1050,xfy,>>=)	% monad bind
	,	op(100,fx,'<?>')
	,	op(800,xfx,'</>')	
	,	op(100,fx,?)
	]).

