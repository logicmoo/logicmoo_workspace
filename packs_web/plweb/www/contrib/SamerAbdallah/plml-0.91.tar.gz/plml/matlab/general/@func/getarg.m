function a=getarg(c,n)
% GETARG - Extract a bound argument from a FUNC object
% getarg :: (func (D1,...,Dn)->R, k:natural) -> Dk
a=c.args{n};
