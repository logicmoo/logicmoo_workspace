function Y=subs(X,varargin)
% subs - Array reference as a function
%
% subs(A,...) = A(...)
%
% Colon can be be used if quoted:
%    subs(A,':') = A(:)
% End indexing cannot be used, eg subs(A,'end') does not
% work as A(end)

Y=X(varargin{:});
