function str=tostring(c)
% TOSTRING - Implementation of string conversion for FUNC objects
%
% tostring :: func -> string

str=[];
slots=c.slots; m=length(slots);
args=c.args;   l=length(args);
n=max(slots);
if l<n, args=[args cell(1,n-l)]; l=n; end;
for i=1:m
	args{slots(i)}=['#' num2str(i)];
end

for i=1:l
	str=[str tostring(args{i}) ','];
end
if n>0, str=[str ' ']; end
if isa(c.fn,'function_handle') fstr=['@' func2str(c.fn)];
elseif isa(c.fn,'inline') fstr=['\' char(c.fn) '\'];
end
str=[ fstr '(' str '...)'];

