function display(c)
% DISPLAY - Display FUNC object as string

disp(tostring(c));
