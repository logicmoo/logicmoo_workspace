function Y=col(X,I)
% col - returns selected columns
% col :: [[N,M]->A], [[L]->natural] -> [[N,L]->A].

Y=X(:,I);
