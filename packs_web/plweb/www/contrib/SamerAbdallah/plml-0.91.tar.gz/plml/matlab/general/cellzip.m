function Y=cellzip(fn,varargin)
% cellzip - Zip cell arrays with a function 
%
% cellzip :: (
% 	(D1,...,Dn)->R	                  ~ function of n arguments,
% 	 {[size]->D1}, ..., {[size]->Dn}	~ n cell arrays of appropriate types
% ) -> {[size]->R}                	~ cell array of results

% preallocate to fix size
sizes=cellmap(@size,varargin);
sz=sizes{1};
for i=1:nargin-1
	if ~all(sizes{i}==sz), error('Sizes do not match'); end 
end

Y=cell(sz);

for i=1:prod(sz)
	args=cellmap(@(c)c{i},varargin);
	Y{i}=feval(fn,args{:});
end

	
