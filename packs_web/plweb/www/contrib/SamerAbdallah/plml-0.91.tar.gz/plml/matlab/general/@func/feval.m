function varargout=feval(c,varargin)
% FEVAL: Evaluate curried function
%
% FEVAL(cfn,a1,a2,...)
%     cfn MUST be a curried function structure (not an ordinary function)
%     The given parameters a1, a2, etc. are bound to the arguments of cfn,
%     and eventually to the arguments of a matlab function, possibly
%     permuted according to cfn.slots (see CFPERM)

% first, fill available slots in arg list using supplied args
if ~isa(c,'func'),
	[varargout{1:max(1,nargout)}] = builtin('feval',c,varargin{:});
	return;
%	error('This shouldn''t be happening!');
end
m=min(length(c.slots),length(varargin));
args=c.args;
args(c.slots(1:m))=varargin(1:m);

% append any left over args
args=cat(2,args,varargin(m+1:end));
if nargout==0
	feval(c.fn,args{:});
else
	[varargout{1:max(1,nargout)}] = feval(c.fn,args{:});
end

