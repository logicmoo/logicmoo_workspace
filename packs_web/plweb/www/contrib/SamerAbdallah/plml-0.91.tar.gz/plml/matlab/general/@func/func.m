function c=func(fn,varargin)
% A func is a partially applied function: Any given function can
% have some arguments bound to some given parameters, producing a
% new function which needs only the remaining unbound parameters to
% be supplied. In addition, the order in which parameters supplied
% in a subsequent invocation are bound to unbound arguments can be
% controlled using a slot permutation mechanism. Subscripting operation
% () is overloaded so that function application works in the normal
% way except when there are no arguments, in which case you must use FEVAL.
%
% For example, if linspace is a function such that
%
%    linspace(a,b,n)
%
% returns an array of n values linearly spaced between a and b,
% then after
%
%    fromzero=func(@linspace,0)
%
% fromzero(b,n) returns n linearly spaced values from 0 to b.
% The arguments can be permuted, eg,
%
%    perm(func(@linspace),[3 1 2])
%
% returns a function that takes the arguments in the order (n,a,b)
% instead of (a,b,n). Permutation and binding can be combined, eg
%
%    countdown=bind(perm(func(@linspace),[3 2 1]),10)
%    countdown(5,50)
%    ans=
%       50 45 40 35 30 25 20 15 10  5
%
% See Also:
%    PERM, BIND, CURRY, FEVAL, BINDAT
%
% Internal structure:
%    cfn.fn    : an ordinary matlab function handle
%    cfn.args  : a cell array with bound arguments filled in in the order
%               that the ordinary function fn expects them. There may be 
%               empty slots if the arguments have been permuted (see CFPERM)
%    cfn.slots : List of empty slots in the order that they are intended to be
%                bound when this curried function is evaluated or has more
%                parameters bound. Eg, the first parameter will be bound to
%                to the slots(1)'th argument of the eventual call to cfn.fn

% default function is null function

if nargin<1, fn=@nullfn; end
if isa(fn,'func'), c=fn;
else
	c.fn=fn;
	c.args=varargin;
	c.slots=[];
	c=class(c,'func',inline(''));
end

function nullfn(varargin)
