function Y=paren(X,varargin)
% paren - array dereferencing as a function
%
% See also SUBS: paren also accepts ':' and 'end'

n=length(varargin);
for i=1:n
	if strcmp(varargin{i},'end')
		varargin{i}=size(X,i);
	end
end
Y=X(varargin{:});
