function cfn=bindat(fn,varargin)
% bindat - Create function with bound arguments at given positions
% 
% BINDAT(fn,positions,arguments)
%    If fn is an ordinary function handle, the parameters a1, a2 etc
%    are bound at the positions given
%
%    If fn is a closure as returned by FUNC, BIND, or PERM,
%    the given parameters are bound to the specified slots of the function.
%
% Eg, a function which divides a value by 4 can be given as
%
%    quarter = bindat(@rdivide,2,2);
%    quarter(8)
%    ans = 2

if ischar(fn), fn=str2func(fn); end
if ~isa(fn,'func'), fn=func(fn); end
cfn=bindat(fn,varargin{:});
