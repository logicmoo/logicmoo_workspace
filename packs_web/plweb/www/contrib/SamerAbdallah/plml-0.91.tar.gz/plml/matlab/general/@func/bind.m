function c=bind(c,varargin)
% BIND: Bind arguments to a func to create partially applied function
% 
% BIND(fn,a1,a2,..)
%    fn is curried function returned by FUNC, BIND or PERM,
%    the given parameters are bound to the free slots of the function
%    and a new curried function is returned.

% There is a stupid f-ing bug in Matlab - if ANY of the paremeters
% to bind are function objects, then this function gets called, even
% if the first parameter is just an ordinary function pointer.
if ~isa(c,'func'), c=curry(c,varargin{:}); return; end;

% first, fill available slots in arg list using supplied args
m=min(length(c.slots),length(varargin));
c.args(c.slots(1:m))=varargin(1:m);

% remove filled slots
c.slots=c.slots(m+1:end);

% append any left over args
c.args=cat(2,c.args,varargin(m+1:end));

