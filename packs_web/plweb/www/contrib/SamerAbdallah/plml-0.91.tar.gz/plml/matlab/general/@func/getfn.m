function fn=getfn(c)
% GETFN - Get ordinary function handle from FUNC object

fn=c.fn;
