function B=cellget(A,varargin)
% cellget - Cell array reference as ordinary function
%
% cellget :: {[N]->A}, 1..N -> A.
% cellget :: {[N,M]->A}, 1..N, 1..M -> A.
% 
% etc.

B=A{varargin{:}};
			
