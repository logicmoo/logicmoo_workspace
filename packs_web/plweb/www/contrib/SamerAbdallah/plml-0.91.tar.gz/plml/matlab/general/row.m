function Y=row(X,I), Y=X(I,:);
% row - returns selected rows of a 2D array
% row :: [[N,M]->A], [[L]->A] -> [[L,M]->A].
