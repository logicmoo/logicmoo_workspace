function c=perm(c,slots)
% PERM: permute arguments to a curried function

% PERM(cfn,perm)
%    cfn can be an ordinary function handle or a curried function as returned
%    by BIND or PERM.
%   
%    The 1st argument of PERM(F,P) will bind to the P(1)'th argument of F.
%    Sequential permutations compose properly.
%    P must be a complete permutation: if length(P)=L, then P must
%    contain each of the intergers 1 to P exactly once.
%    The binding order of arguments after the Lth is not affected.

m=length(c.slots);
n=length(slots);
l=length(c.args);
if m<n,     c.slots=[c.slots l+1:l+n-m]; 
elseif m>n, slots=[slots n+1:m]; end
c.slots=c.slots(slots);

