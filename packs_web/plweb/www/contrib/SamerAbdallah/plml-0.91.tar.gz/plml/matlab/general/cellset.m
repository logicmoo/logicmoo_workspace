function A=cellset(n,B,A)
% cellset - set element of cell array to new value and return new cell array
%
% cellset :: [N], A, {[N]} -> {[N]}.
% cellset :: N:natural, A -> {[N]}.
%
% The order of arguments is a bit weird here. Also, if the third argument
% is not present, this function returns a cell array which is empty apart
% from the last (Nth) element.

	if nargin<3, A=cell(n,1); end;
	A{n}=B;
			
