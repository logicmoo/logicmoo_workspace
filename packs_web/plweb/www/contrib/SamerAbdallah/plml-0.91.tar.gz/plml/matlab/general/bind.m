function cfn=bind(fn,varargin)
% bind - Create a partially applied function
% 
% BIND(fn,a1,a2,...)
%    If fn is an ordinary function, the parameters a1, a2 etc
%    are bound as the first few arguments
%
%    If fn is a function object as returned by FUNC, BIND, or PERM,
%    the given parameters are bound to the free slots of the function
%    and a new partially applied function is returned.
%

if ischar(fn), fn=str2func(fn); end
if ~isa(fn,'func'), fn=func(fn); end
cfn=bind(fn,varargin{:});
