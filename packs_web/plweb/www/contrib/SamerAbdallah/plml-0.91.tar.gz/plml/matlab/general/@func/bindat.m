function c=bindat(c,pos,varargin)
% BINDAT: Bind arguments at specified positions to create partially applied 
% function
% 
% BIND(cfn,pos,a1,a2,..)
%    If cfn is an ordinary function, the parameters a1, a2 etc
%    are bound at the positions specified in pos(1),pos(2), etc.
%    Otherwise, the same as BIND.
%
%    See BIND

% need to make sure pos is a complete permutation before
% calling perm
pos=[pos setdiff(1:max(pos),pos)];
c=bind(perm(c,pos),varargin{:});

