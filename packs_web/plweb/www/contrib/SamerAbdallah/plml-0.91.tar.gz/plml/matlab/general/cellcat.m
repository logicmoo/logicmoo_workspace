function Y=cellcat(dim,X), Y=cat(dim,X{:});
% cellcat - join contents of cell array into ordinary array
%
% cellcat :: 
%    E:natural ~'dimension to concatenate along',
%    {[N]->A}  ~'cell array of N values'
% -> [Size->A] :- Size=[ones(1,1-E),E].
%
% It's faster than cell2mat
