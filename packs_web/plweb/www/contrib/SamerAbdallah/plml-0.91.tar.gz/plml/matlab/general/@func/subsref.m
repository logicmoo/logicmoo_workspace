function varargout=subsref(c,S)
% SUBSREF - Subscript referencing for FUNC objects
%
% f(a,b,c)=feval(f,a,b,c) - parenthesis subsref invokes the function
% f{a,b,c}=bind(f,a,b,c) - braces subsref binds more arguments


s=S(1);
switch s.type
	case '()'
		% first, fill available slots in arg list using supplied args
		m=min(length(c.slots),length(s.subs));
		args=c.args;
		args(c.slots(1:m))=s.subs(1:m);

		% append any left over args
		args=cat(2,args,s.subs(m+1:end));
		%[varargout{1:max(1,nargout)}] = feval(c.fn,args{:});
		[varargout{1:nargout}] = feval(c.fn,args{:});
	case '{}'
		varargout{1}=bind(c,s.subs{:});
		if length(S)>1,
			% [varargout{1:max(1,nargout)}] = subsref(varargout{1},S(2:end));
			[varargout{1:nargout}] = subsref(varargout{1},S(2:end));
		end
end
