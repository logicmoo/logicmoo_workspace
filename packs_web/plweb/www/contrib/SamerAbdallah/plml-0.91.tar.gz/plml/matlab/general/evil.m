function varargout=evil(f,args)
   [varargout{1:max(1,nargout)}] = feval(f,args{:});
	
