function s=char(f)
% CHAR - convert FUNC object to character string
% char :: func -> string

s=tostring(f);
