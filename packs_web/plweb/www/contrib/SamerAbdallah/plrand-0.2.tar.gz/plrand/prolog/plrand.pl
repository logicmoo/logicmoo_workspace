/*
 * Prolog part of random generator library
 * Samer Abdallah (2009)
*/
	  
:- module(plrand, [
		rv/2 					% -Spec, -Type
	,	sample/4				% +Dist, -Value, +StateIn, -StateOut
	,	sample/2				% +Dist, -Value
	,	get_rnd_state/1	% -State
	,	set_rnd_state/1	% +State
	,	is_rnd_state/1		% +State
	,	init_rnd_state/1	% -State
	,	randomise/1			% -State
	,	with_rnd_state/1	% :Goal
	,	reset_rnd_state/0 
	]).
	
:-	load_foreign_library(foreign(plrand)).
:- meta_predicate with_rnd_state(:).

%% rv(-Spec, -Type) is multi.
%
%  Unifies Spec and Type with specifications for all the distributions
%  known to the system.
%
%  @param Spec is a term representing a distribution that can be used
%         with sample/2 or sample/4. The head functor represents the
%         distribution to sampled from and any arguments represent the
%         types of the corresponding arguments to be used when sampling.
%  @param Type represents the type of the sampled value. 
rv( uniform01, nonneg).
rv( normal,    real).
rv( exponential, nonneg).
rv( gamma(nonneg), nonneg).
rv( studentst(nonneg), real).
rv( poisson(nonneg), natural).
rv( invgamma(nonneg), nonneg).
rv( beta(nonneg,nonneg), nonneg).
rv( zeta(nonneg), nonneg).
rv( binomial(nonneg,natural), natural).
rv( dirichlet(natural,list(nonneg)), list(nonneg)).
rv( dirichlet(list(nonneg)), list(nonneg)).
rv( stable(nonneg,real), real).
rv( bernoulli(nonneg), atom).
rv( bernoulli(nonneg), atom).
rv( discrete(natural,list(nonneg)),natural).
rv( discrete(list(nonneg)),natural).

%% sample( +DistExpression, -Value) is det.
%% sample( +DistExpression, -Value, +StateIn, -StateOut) is det.
%
% 	sample/2 and sample/4 implement a small language for describing
%  and sampling from a distribution. 
%
%  sample/2 uses and modifies the global state.
%  sample/4 uses a given random generator state and returns the state
%  on completion, and is designed to compatible with DCG syntax to hide
%  the threading of the random state through several consecutive calls.
%
%  DistExpression is an expression describing a distribution.  The head
%  functor can be a distribution name (as listed by rv/2) or one of a number
%  of arithmetic operators or term constructors. The arguments (in almost all
%  cases) can then be further DistExpressions which are evaluated recursively. 
%  Valid non-distributional termsare:
%
%  	* X*Y
%		returns product of samples from X and Y
%  	* X/Y
%		returns ratio of samples from X and Y
%  	* X+Y
%		returns sum of samples from X and Y
%  	* X-Y
%		returns difference of samples from X and Y
%  	* -X
%		returns the negation of a sample from X
%		* sqrt(X)
%		returns square root of sample from X
%		* [X,Y,...]
%     return samples from X, Y etc in a list
%		* rep(N,X)
%     returns N independent sample from X in a list (N must be a constant)
%     * factorial(N,X)
%     returns N independent sample from X in an N argument term \(X1,...,XN)
%     * <any number>
%     returns itself as a constant
%
%     For example
%
%     ?- sample(invgamma(1)*rep(8,discrete(dirichlet(rep(4,0.5)))),X).
%     X = [3, 2, 3, 3, 3, 1, 2, 2] .

sample( uniform01, X)   --> sample_Uniform01(X).
sample( normal, X)      --> sample_Normal(X).
sample( exponential, X) --> sample_Exponential(X).
sample( gamma(A), X)    --> sample(A,A1), sample_Gamma(A1,X).
sample( poisson(A), X)  --> sample(A,A1), sample_Poisson(A1,X).
sample( invgamma(A), X) --> sample(A,A1), sample_Gamma(A1,Y), {X is 1/Y}.
sample( beta(A,B), X)   --> sample(A,A1), sample(B,B1), sample_Beta(A1,B1,X).
sample( zeta(A), X)     --> sample(A,A1), sample_Zeta(A1,X1), {X is integer(X1)}.
sample( pareto(A), X)   --> sample(A,A1), sample_Uniform01(Y), {X is (1-Y)**(-1/A1) }.
sample( binomial(P,N), X)  --> sample(P,P1), sample(N,N1), sample_Binomial(P1,N1,X).
sample( dirichlet(N,A), X) --> sample(A,A1), sample_Dirichlet(N,A1,X).
sample( dirichlet(A), X)   --> sample(A,A1), {length(A1,N)}, sample_Dirichlet(N,A1,X).
sample( stable(A,B), X)    --> sample(A,A1), sample(B,B1), sample_Stable(A1,B1,X).
sample( discrete(N,P), X)  --> sample(P,P1), sample_Discrete(N,P1,X).
sample( discrete(P), X)    --> sample(P,P1), {length(P1,N)}, sample_Discrete(N,P1,X).
sample( bernoulli(P), X)   --> sample(P,P1), sample_Uniform01(U), {U<P1->X=1;X=0}.
sample( studentst(V), X)   --> sample(V/2,V1), sample(normal*sqrt(V1/gamma(V1)),X).


sample( X*Y, Z) --> sample(X,X1), sample(Y,Y1), {Z is X1*Y1}.
sample( X/Y, Z) --> sample(X,X1), sample(Y,Y1), {Z is X1/Y1}.
sample( X+Y, Z) --> sample(X,X1), sample(Y,Y1), {Z is X1+Y1}.
sample( X-Y, Z) --> sample(X,X1), sample(Y,Y1), {Z is X1-Y1}.
sample( -X, Z)  --> sample(X,X1), {Z is -X1}.
sample( sqrt(X), Z) --> sample(X,X1), {Z is sqrt(X1)}.

sample( [], []) --> [].
sample( [X|XX], [Z|ZZ]) --> sample(X,Z), sample(XX,ZZ).
sample( rep(N,X), Z) --> {length(Z,N)}, seqmap(sample(X),Z).
sample( factorial(N,X), Z) --> {functor(Z,\,N)}, seqmapargs(sample(X),N,Z).
sample( Tuple, Value) -->
	{functor(Tuple,F,N), functor(Value,F,N), tuple_functor(F)},
	seqmapargs(rand,N,Tuple,Value).

sample( N,N,S,S) :- number(N), !.

sample(M,X)     :- get_rnd_state(S1), sample(M,X,S1,S2), set_rnd_state(S2).


%% get_rnd_state(-State) is det.
%
%  Unifies State with the current global RNG state.
%  @see set_rnd_state/1


%% set_rnd_state(+State) is det.
%
%  Sets the globab RNG state to State.
%  @see get_rnd_state/1

%% init_rnd_state(-State) is det.
%
%  Unifies State with the state that was set at load time.
%  @see reset_rnd_state/0

%% reset_rnd_state is det.
%  
%  Resets the global random state to the initial one set at load time.
%  This is the same as the one returned by init_rnd_state/1.
%
%  @see init_rnd_state/1
%  @see set_rnd_state/1
reset_rnd_state :- init_rnd_state(S0), set_rnd_state(S0).

%% is_rnd_state(+State) is semidet.
%
%  Succeeds if State is a BLOB atom representing a random generator state.


%% with_rnd_state(:Callable) is nondet.
%
%  Runs DCG phrase Callable using the current global RNG state and setting
%  the global RNG state afterwards.
%
%  @param Callable must be a DCG phrase or callable that takes two more
%         arguments, ie, that can be used with call(:Callable,+S1,-S2)
with_rnd_state(P) :- get_rnd_state(S1), phrase(P,S1,S2), set_rnd_state(S2).


% randomise(-State) is det.
%
% Unifies State with a new and truely random state obtained by
% taking bits from /dev/random.

tuple_functor(\).
tuple_functor(tuple).
tuple_functor(vec).

seqmapargs(P,N,X1) -->
	(	{N>0}
	->	{succ(M,N), arg(N,X1,X1N)},
		call(P,X1N),
		seqmapargs(P,M,X1)
	;	[]
	).
seqmapargs(P,N,X1,X2) -->
	(	{N>0}
	->	{succ(M,N), arg(N,X1,X1N), arg(N,X2,X2N)},
		call(P,X1N,X2N),
		seqmapargs(P,M,X1,X2)
	;	[]
	).

seqmap(_,[])             --> [].
seqmap(P,[A|AX])         --> call(P,A), seqmap(P,AX).
seqmap(_,[],[])          --> [].
seqmap(P,[A|AX],[B|BX])  --> call(P,A,B), seqmap(P,AX,BX).


