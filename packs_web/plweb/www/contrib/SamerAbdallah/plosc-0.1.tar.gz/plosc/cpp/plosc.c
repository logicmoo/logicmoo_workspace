/*
 *  Copyright (C) 2009 Samer Abdallah
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 */

#include <SWI-Stream.h>
#include <SWI-Prolog.h>

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <lo/lo.h>

// BLOB to hold a lo_address
static PL_blob_t addr_blob;

install_t install();

foreign_t mk_address( term_t host, term_t port, term_t addr); 
foreign_t is_address( term_t addr); 
foreign_t send_now( term_t addr, term_t msg, term_t args); 
//foreign_t now( term_t sec, term_t frac);
//foreign_t send_timestamped( term_t addr, term_t msg, term_t args, term_t sec, term_t frac); 
foreign_t send_at( term_t addr, term_t msg, term_t args, term_t time); 

int addr_release(atom_t a) {
	PL_blob_t *type;
	size_t    len;
	void *p;

	p=PL_blob_data(a,&len,&type);
	if (p) {
		lo_address_free(*(lo_address *)p);
	}
	return TRUE;
}

install_t install() { 
	PL_register_foreign("osc_mk_address", 3, (void *)mk_address, 0);
	PL_register_foreign("osc_is_address", 1, (void *)is_address, 0);
	PL_register_foreign("osc_send_now",   3, (void *)send_now, 0);
	PL_register_foreign("osc_send_at",    4, (void *)send_at, 0);
//	PL_register_foreign("osc_now",        2, (void *)now, 0);

	// F_rand4 = PL_new_functor(PL_new_atom("rand"), 4);

	addr_blob.magic = PL_BLOB_MAGIC;
	addr_blob.flags = PL_BLOB_UNIQUE;
	addr_blob.name = "plosc_address";
	addr_blob.acquire = 0; // rs_acquire;
	addr_blob.release = addr_release;
	addr_blob.compare = 0; // rs_compare;
	addr_blob.write   = 0; // rs_write;
}

// throws a Prolog exception to signal type error
static int type_error(term_t actual, const char *expected)
{ 
	term_t ex = PL_new_term_ref();

  PL_unify_term(ex, PL_FUNCTOR_CHARS, "error", 2,
		      PL_FUNCTOR_CHARS, "type_error", 2,
		        PL_CHARS, expected,
		        PL_TERM, actual,
		      PL_VARIABLE);

  return PL_raise_exception(ex);
}

static int osc_error(int errno, const char *errmsg, const char *msg)
{ 
	term_t ex = PL_new_term_ref();

  PL_unify_term(ex, PL_FUNCTOR_CHARS, "error", 2,
		      PL_FUNCTOR_CHARS, "osc_send_error", 3,
		        PL_INTEGER, errno,
		        PL_CHARS, errmsg,
		        PL_CHARS, msg,
		      PL_VARIABLE);

  return PL_raise_exception(ex);
}


// put lo_address into a Prolog BLOB 
static int unify_addr(term_t addr,lo_address a) {
	return PL_unify_blob(addr, &a, sizeof(lo_address), &addr_blob); 
}

// get lo_address from BLOB
static int get_addr(term_t addr, lo_address *a)
{ 
	PL_blob_t *type;
	size_t    len;
	lo_address *a1;
  
	PL_get_blob(addr, (void **)&a1, &len, &type);
	if (type != &addr_blob) {
		return type_error(addr, "plosc_address");
	} else {
		*a=*a1;
		return TRUE;
	}
} 

// get Prolog (Unix) time value and convert to OSC timestamp
static int get_prolog_time(term_t time, lo_timetag *ts) {
	double t, ft;
	int 	ok = PL_get_float(time, &t);

	ft=floor(t);
	ts->sec = ((uint32_t)ft)+2208988800u;
	ts->frac = (uint32_t)(4294967296.0*(t-ft));
	return ok;
}

/*
static int get_timetag(term_t sec, term_t frac, lo_timetag *ts) {
	int64_t	s, f;
	int 	ok = PL_get_int64(sec, &s) && PL_get_int64(frac, &f);
	ts->sec = s;
	ts->frac = f;
	return ok;
}
*/


static int get_msg(term_t msg, char **m) {
	return PL_get_chars(msg, m, CVT_ATOM | CVT_STRING);
}

// parse a list of Prolog terms and add arguments to an OSC message 
static int add_msg_args(lo_message msg, term_t list)
{
	term_t 	head=PL_new_term_ref();

	// copy term ref so as not to modify original
	list=PL_copy_term_ref(list);

	while (PL_get_list(list,head,list)) {
		atom_t name;
		int	 arity;
		const char  *type;

		if (!PL_get_name_arity(head,&name,&arity)) return type_error(head,"term");
		type=PL_atom_chars(name);
		switch (arity) {
		case 1: {
				term_t a1=PL_new_term_ref();
				PL_get_arg(1,head,a1);

				if (!strcmp(type,"int")) {
					int x;
					if (!PL_get_integer(a1,&x)) return type_error(a1,"integer");
					lo_message_add_int32(msg,x);
				} else if (!strcmp(type,"double")) {
					double x;
					if (!PL_get_float(a1,&x)) return type_error(a1,"float");
					lo_message_add_double(msg,x);
				} else if (!strcmp(type,"string")) {
					char *x;
					if (!PL_get_chars(a1,&x,CVT_ATOM|CVT_STRING)) return type_error(a1,"string");
					lo_message_add_string(msg,x);
				} else if (!strcmp(type,"symbol")) {
					char *x;
					if (!PL_get_chars(a1,&x,CVT_ATOM)) return type_error(a1,"atom");
					lo_message_add_symbol(msg,x);
				} else if (!strcmp(type,"float")) {
					double x;
					if (!PL_get_float(a1,&x)) return type_error(a1,"float");
					lo_message_add_float(msg,(float)x);
				}
				break;
			}
		case 0: {
				if (!strcmp(type,"true")) lo_message_add_true(msg);
				else if (!strcmp(type,"false")) lo_message_add_false(msg);
				else if (!strcmp(type,"nil")) lo_message_add_nil(msg);
				else if (!strcmp(type,"inf")) lo_message_add_infinitum(msg);
				break;
			}
		}
	}
	if (!PL_get_nil(list)) return type_error(list,"nil");
	return TRUE;
}

static int send_msg_timestamped(lo_address a, lo_timetag *ts, char *path, term_t args)
{
	lo_message msg=lo_message_new();
	lo_bundle  bun=lo_bundle_new(*ts);

	if (add_msg_args(msg,args)) {
		int ret;

		lo_bundle_add_message(bun,path,msg);
		ret = lo_send_bundle(a,bun);
		lo_message_free(msg);
		lo_bundle_free(bun);
		if (ret==-1) {
			return osc_error(lo_address_errno(a),lo_address_errstr(a),path);
		} else {
			return TRUE;
		}
	} else return FALSE;
}

static int send_msg(lo_address a, char *path, term_t args)
{
	lo_message msg=lo_message_new();

	if (add_msg_args(msg,args)) {
		if (lo_send_message(a,path,msg)==-1) {
			lo_message_free(msg);
			return osc_error(lo_address_errno(a),lo_address_errstr(a),path);
		} else {
			lo_message_free(msg);
			return TRUE;
		}
	} else return FALSE;
}

foreign_t mk_address(term_t host, term_t port, term_t addr) { 
	char *h, *p;

	if (PL_get_chars(host, &h, CVT_ATOM | CVT_STRING)) {
		if (PL_get_chars(port, &p, CVT_INTEGER)) {
			lo_address a = lo_address_new(h,p);
			return unify_addr(addr,a);
		} else {
			return type_error(host,"atom");
		}
	} else {
		return type_error(host,"integer");
	}
}

/*
foreign_t now(term_t sec, term_t frac) { 
	lo_timetag ts;
	int64_t s, f;

	lo_timetag_now(&ts);
	s=ts.sec; f=ts.frac;
	return PL_unify_int64(sec,s) && PL_unify_int64(frac,f);
}
*/


// set current random state structure to values in Prolog term
foreign_t is_address(term_t addr) { 
	PL_blob_t *type;
	return PL_is_blob(addr,&type) && type==&addr_blob;
}


foreign_t send_at(term_t addr, term_t msg, term_t args, term_t time) {
	lo_address 	a;
	lo_timetag  ts;
	char			*m;

	return get_addr(addr,&a) &&
			get_prolog_time(time,&ts) &&
			get_msg(msg, &m) &&
			send_msg_timestamped(a,&ts,m,args);
}

/*
foreign_t send_timestamped(term_t addr, term_t msg, term_t args, term_t secs, term_t frac) {
	lo_address 	a;
	lo_timetag  ts;
	char			*m;

	return get_addr(addr,&a) &&
			get_timetag(secs,frac,&ts) &&
			get_msg(msg, &m) &&
			send_msg_timestamped(a,&ts,m,args);
}
*/



foreign_t send_now(term_t addr, term_t msg, term_t args) {
	lo_address 	a;
	char			*m;

	return get_addr(addr,&a) &&
			get_msg(msg, &m) &&
			send_msg(a,m,args);
}

#if 0
// extract long from a'th argument of Prolog term
static int get_long_arg(int a, term_t state, long *p)
{ 
	term_t arg = PL_new_term_ref();

	_PL_get_arg(a, state, arg);
	return get_long(arg, p);
}

// extract double from a'th argument of Prolog term
static int get_double_arg(int a, term_t state, double *p)
{ 
	term_t arg = PL_new_term_ref();

	_PL_get_arg(a, state, arg);
	return get_double(arg, p);
}
#endif


