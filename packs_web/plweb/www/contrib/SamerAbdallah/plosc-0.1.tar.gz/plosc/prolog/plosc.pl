/*
 * Prolog part of random generator library
 * Samer Abdallah (2009)
*/
	  
:- module(plosc, [
		osc_mk_address/3	% +Host:atom, +Port:nonneg, -Ref
	,	osc_is_address/1  % +Ref
	,	osc_send/3			% +Ref, +Path:atom, +Args:list(OSCArg)
	,	osc_send/4			% +Ref, +Path:atom, +Args:list(OSCArg), +Time:float
	]).
	
:-	load_foreign_library(foreign(plosc)).

%% osc_mk_address(+Host:atom, +Port:nonneg, -Ref) is det.
%
%  Construct a BLOB atom representing an OSC destination.
%
%  @param Host is the hostname or IP address of the OSC receiver
%  @param Port is the port number of the OSC receiver

%% osc_is_address(+Ref) is semidet.
%
%  Succeeds if Ref is an OSC address created by osc_mk_address/2

%% osc_send(+Ref, +Path:atom, +Args:list(OSCArg)) is det.
%% osc_send(+Ref, +Path:atom, +Args:list(OSCArg), +Time:float) is det.
%
%  Sends an OSC message scheduled for immediate execution (osc_send/3) or
%  at a given time (osc_send/4).
%
%  @param Ref is an OSC address BLOB as returned by osc_mk_address.
%  @param Path is an atom representing the OSC message path, eg '/foo/bar'
%  @param Args is a list of OSC message arguments, which can be any of:
%  	* string(+X:text)
%  	String as atom or Prolog string
%  	* symbol(+X:atom)
%  	* double(+X:float)
%  	Double precision floating point
%  	* float(+X:float)
%  	Single precision floating point
%  	* int(+X:integer)
%  	* true
%  	* false
%  	* nil
%  	* inf
%
osc_send(A,B,C) :- osc_send_now(A,B,C,T1).
osc_send(A,B,C,T) :- T1 is T, osc_send_at(A,B,C,T1).



