definition(A, B) :-
	A=nutrition,
	B='Nutrition is the science of food and its relationship to health.'.
definition(A, B) :-
	A='nutritional sciences',
	B='The nutritional sciences deal with the nature and distribution of nutrients in food, their metabolic effects, and the consequences of inadequate food intake.'.
definition(A, B) :-
	A='nutritional sciences',
	B='The nutritional sciences deal with the nature and distribution of nutrients in food, their metabolic effects, and the consequences of inadequate food intake.'.
definition(A, B) :-
	A=nutrients,
	B='Nutrients are chemical compounds in foods that are absorbed and used to promote health. Some nutrients are essential because they cannot be synthesized by the body and thus must be derived from the diet.'.
definition(A, B) :-
	A='essential nutrients',
	B='Essential nutrients include vitamins, minerals, amino acids, fatty acids, and some carbohydrate as a source of energy.'.
definition(A, B) :-
	A='nonessential nutrients',
	B='Nonessential nutrients are those that the body can synthesize from other compounds, although they may also be derived from the diet.'.
definition(A, B) :-
	A='nutrient division',
	B='Nutrients are generally divided into macronutrients and micronutrients.'.
definition(A, B) :-
	A=macronutrients,
	B='Macronutrients constitute the bulk of the diet and supply energy as well as essential nutrients needed for growth, maintenance, and activity. Carbohydrates, fats (including essential fatty acids), proteins, macrominerals, and water are macronutrients.'.
definition(A, B) :-
	A='macronutrient process',
	B='Carbohydrates are converted to glucose and other monosaccharides; fats, to fatty acids and glycerol; and proteins, to peptides and amino acids. These macronutrients are interchangeable as sources of energy; fats yield 9 kcal/g; proteins and carbohydrates yield 4 kcal/g. Ethanol, not usually considered a nutrient, yields 7 kcal/g.'.
definition(A, B) :-
	A='carbohydrate benefit',
	B='Carbohydrates and fat spare tissue protein. Unless sufficient nonprotein calories are available from either dietary sources or tissue stores (particularly of fat), protein cannot be used efficiently for tissue maintenance, replacement, or growth, and considerably more dietary protein is required for positive nitrogen balance.'.
definition(A, B) :-
	A='essential amino acids',
	B='Essential amino acids (EAAs) are the components of proteins that make them essential in the diet. Of the 20 amino acids in proteins, 9 are essential, ie, required in the diet because they cannot be synthesized in the body. Eight EAAs are required by all humans. Infants require one more, histidine.'.
